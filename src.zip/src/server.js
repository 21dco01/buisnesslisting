const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

// Initialize Express app
const app = express();

// Connect to MongoDB database
mongoose.connect('mongodb://localhost:27017/login', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

// Create a User model
const User = mongoose.model('User', {
  name: String,
  email: String,
  password: String
});

// Use bodyParser middleware to parse incoming JSON data
app.use(bodyParser.json());

// Define the registration endpoint
app.post('https://www.thunderclient.com/api/register', async (req, res) => {
  try {
    // Create a new user with the given data
    const user = new User(req.body);

    // Save the user to the database
    await user.save();

    // Return a success message
    res.json({ message: 'User registered successfully' });
  } catch (error) {
    // Return an error message if there was a problem
    res.status(500).json({ error: error.message });
  }
});

// Start the server
app.listen(3000, () => {
  console.log('Server started on port 3000');
});
